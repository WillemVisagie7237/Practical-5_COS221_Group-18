// models/movie.js
const pool = require('../db');

// Define movie model
const Movie = {
  getAll: async () => {
    const conn = await pool.getConnection();
    try {
      return await conn.query('SELECT * FROM movie');
    } finally {
      conn.release();
    }
  },
  // Implement other CRUD operations as needed
};

module.exports = Movie;
