// moviesController.js (controllers)
const Movie = require('../models/movie');

// Controller functions for movies
exports.getAllMovies = async (req, res) => {
  try {
    const movies = await Movie.findAll();
    res.json(movies);
  } catch (error) {
    console.error('Error fetching movies:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};




// Other CRUD operation
// (createMovie, getMovieById, updateMovie, deleteMovie)
