const express = require('express');
const session = require('express-session');
const mariadb = require('mariadb');
const path = require('path');

const app = express();
const port = 3007;

const pool = mariadb.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Johan12?',
  database: 'the7',
  connectionLimit: 10
});

app.use(session({
  secret: 'secret',
  resave: false,
  saveUninitialized: true
}));

const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    return next();
  }
  res.redirect('/login.html');
};

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  console.log(`Incoming request: ${req.method} ${req.url}`);
  next();
});

app.use(express.static(path.join(__dirname, 'views')));

app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  const conn = await pool.getConnection();
  try {
    const user = await conn.query('SELECT * FROM user WHERE username = ? AND password = ?', [username, password]);
    if (user.length > 0) {
      req.session.user = user[0];
      res.redirect('/Main.html');
    } else {
      res.redirect('/login.html?error=invalid_credentials');
    }
  } catch (err) {
    console.error('Error querying database:', err);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    conn.release();
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login.html');
});


app.post('/content', isAuthenticated, async (req, res) => {
  const { id, title, description, releaseYear, rating, genre, runtime, type } = req.body;

  let conn;
  try {
    conn = await pool.getConnection();
    if (id) {
      // Update existing content
      await conn.query('UPDATE content SET title = ?, description = ?, release_year = ?, rating = ?, genre = ? WHERE id = ?', [title, description, releaseYear, rating, genre, id]);
      if (type === 'movie') {
        await conn.query('UPDATE movie SET runtime = ? WHERE content_id = ?', [runtime, id]);
      } else if (type === 'series') {
        await conn.query('UPDATE series SET seasons = ? WHERE content_id = ?', [runtime, id]);
      }
    } else {
      // Add new content
      const result = await conn.query('INSERT INTO content (title, description, release_year, rating, genre) VALUES (?, ?, ?, ?, ?)', [title, description, releaseYear, rating, genre]);
      const contentId = result.insertId;
      if (type === 'movie') {
        await conn.query('INSERT INTO movie (content_id, runtime) VALUES (?, ?)', [contentId, runtime]);
      } else if (type === 'series') {
        await conn.query('INSERT INTO series (content_id, seasons) VALUES (?, ?)', [contentId, runtime]);
      }
    }
    res.json({ success: true });
  } catch (err) {
    console.error('Error querying database:', err);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    if (conn) conn.release();
  }
});



app.post('/content/delete', isAuthenticated, async (req, res) => {
  const { id, type } = req.body;

  let conn;
  try {
    conn = await pool.getConnection();
    
    // Delete related records from referencing tables first
    if (type === 'movie') {
      await conn.query('DELETE FROM movie WHERE content_id = ?', [id]);
    } else if (type === 'series') {
      await conn.query('DELETE FROM series WHERE content_id = ?', [id]);
    }

    // Then delete the content record
    await conn.query('DELETE FROM content WHERE id = ?', [id]);
    
    res.json({ success: true });
  } catch (err) {
    console.error('Error querying database:', err);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    if (conn) conn.release();
  }
});




// Add Actor
app.post('/persons', isAuthenticated, async (req, res) => {
  const { firstName, lastName, dob,role } = req.body;

  const conn = await pool.getConnection();
  try {
      await conn.query('INSERT INTO person (first_name, last_name, date_of_birth, role) VALUES (?, ?, ?, ?)', [firstName, lastName, dob, role]);
      res.json({ success: true });
  } catch (err) {
      console.error('Error adding actor:', err);
      res.status(500).json({ error: 'Internal server error' });
  } finally {
      conn.release();
  }
});


// Endpoint to add a genre
app.post('/genres', isAuthenticated, async (req, res) => {
  const { genreName } = req.body;

  const conn = await pool.getConnection();
  try {
      await conn.query('INSERT INTO genre (name) VALUES (?)', [genreName]);
      res.json({ success: true });
  } catch (err) {
      console.error('Error adding genre:', err);
      res.status(500).json({ error: 'Internal server error' });
  } finally {
      conn.release();
  }
});

// Endpoint to add a production studio
app.post('/studios', isAuthenticated, async (req, res) => {
  const { studioName, studioCountry, foundingYear, ceo, website } = req.body;

  const conn = await pool.getConnection();
  try {
      await conn.query('INSERT INTO production_studio (name, country, founding_year, ceo, website) VALUES (?, ?, ?, ?, ?)', [studioName, studioCountry, foundingYear, ceo, website]);
      res.json({ success: true });
  } catch (err) {
      console.error('Error adding production studio:', err);
      res.status(500).json({ error: 'Internal server error' });
  } finally {
      conn.release();
  }
});



app.put('/persons/:id', isAuthenticated, async (req, res) => {
  const { id } = req.params;
  const { role, firstName, lastName, dob } = req.body;

  let conn;
  try {
    conn = await pool.getConnection();
    await conn.query('UPDATE person SET role = ?, first_name = ?, last_name = ?, date_of_birth = ? WHERE person_id = ?', [role, firstName, lastName, dob, id]);
    res.json({ success: true });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    if (conn) conn.release();
  }
});

// Delete a person
app.delete('/persons/:id', isAuthenticated, async (req, res) => {
  const { id } = req.params;

  let conn;
  try {
    conn = await pool.getConnection();
    await conn.query('DELETE FROM person WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    if (conn) conn.release();
  }
});









app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
