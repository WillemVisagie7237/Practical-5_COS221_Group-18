document.getElementById('contentForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const id = document.getElementById('id').value;
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const releaseYear = document.getElementById('releaseYear').value;
  const rating = document.getElementById('rating').value;
  const genre = document.getElementById('genre').value;
  const type = document.getElementById('type').value;
  let runtime = null;
  if (type === 'movie') {
    runtime = document.getElementById('runtime').value;
  }

  const data = { id, title, description, releaseYear, rating, genre, runtime, type };

  fetch('/content', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert('Content saved successfully!');
      } else {
        alert('Error saving content.');
      }
    })
    .catch((error) => {
      console.error('Error:', error);
    });
});

document.getElementById('deleteForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const id = document.getElementById('deleteId').value;
  const type = document.getElementById('contentType').value;

  fetch('/content/delete', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ id, type }),
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert('Content deleted successfully!');
      } else {
        alert('Error deleting content.');
      }
    })
    .catch((error) => {
      console.error('Error:', error);
    });
});





function addOrUpdatePerson() {
  const personId = document.getElementById('personId').value;
  const role = document.getElementById('roleSelect').value;
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const dob = document.getElementById('dob').value;

  const data = { personId, role, firstName, lastName, dob };

  let url = '/persons';
  let method = 'POST';

  if (personId) {
    // If personId exists, it's an update operation
    url += `/${personId}`; // Include personId in the URL
    method = 'PUT';
  }

  fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert(`${role} ${personId ? 'updated' : 'added'} successfully!`);
      // Refresh person list or update UI as needed
    } else {
      alert(`Error ${personId ? 'updating' : 'adding'} ${role}.`);
    }
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}

function deletePerson() {
  const personId = document.getElementById('personId').value;

  if (!personId) {
    alert('Please select a person to delete.');
    return;
  }

  fetch(`/persons/${personId}`, {
    method: 'DELETE',
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert('Person deleted successfully!');
      // Refresh person list or update UI as needed
    } else {
      alert('Error deleting person.');
    }
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}
